package com.example.medyassinhamdi_devmobil_mesure_glycemie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    private TextView tvAge,tvResult;
    private SeekBar sbAge;
    private RadioButton rbOui,rbNon;
    private EditText etValeur;
    private Button btnConsulter;


    @Override
    protected void onCreate(Bundle savedInstanceState) { //e3tibaratan public static void main
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        //action sur seekbar bech nkhalilou 3ases yaml update kol mandbadl haja
        sbAge.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                        tvAge.setText("Votre Age :"+i);
                        Log.i("info","onProgressChange"+i);
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {

                    }
                }
        );
    }
    private void init(){
        tvAge=(TextView) findViewById(R.id.tvAge); //findview traja3li view ena castit aliha textview bech trajalo text
        tvResult=(TextView) findViewById(R.id.tvResult);
        sbAge= (SeekBar) findViewById(R.id.sbAge);
        rbOui= (RadioButton) findViewById(R.id.rbOui);
        rbNon= (RadioButton) findViewById(R.id.rbNo);
        etValeur= (EditText) findViewById(R.id.etValeur);
        btnConsulter= (Button) findViewById(R.id.btnConsulter);
    }
    public  void calculer(View v){
        int age;
        float valeurMesuré;
        boolean verifierAge= false;
        boolean verifierValeur=false;
        if(sbAge.getProgress()!=0)
            verifierAge=true;
        else
            Toast.makeText(MainActivity.this,"veullier verifier votre age",Toast.LENGTH_SHORT);
        if(etValeur.getText().toString().isEmpty())
            verifierValeur=true;
        else
            Toast.makeText(MainActivity.this,"vellier verifier votre valeur",Toast.LENGTH_LONG);
        if(verifierAge && verifierValeur){
            age = sbAge.getProgress();
            valeurMesuré= Float.valueOf(etValeur.getText().toString());
            if(rbOui.isChecked())
                if(age>= 13)
                    if(valeurMesuré < 5.0)
                        tvResult.setText("le niveau de glycemie est bas");
                    else if (valeurMesuré>=5.0  && valeurMesuré<=7.2) {
                        tvResult.setText("le niveau de glycemie est normale");
                    }
                    else
                        tvResult.setText("le niveau de glycemie est elevee");
                else if (age >=6 && age<=12)
                    if(valeurMesuré<5.0)
                        tvResult.setText("niveau glycemie et bas");
                    else if (valeurMesuré >=5.0 && valeurMesuré<=10.0 )
                        tvResult.setText("niveau glycemie est minimal");
                    else
                        tvResult.setText("niveau eleve");
                else
                if(valeurMesuré<5.5)
                    tvResult.setText("niveau tres bas");
                else if(valeurMesuré>=5.5 && valeurMesuré<=10.0)
                    tvResult.setText("niv est minimal");
                else
                    tvResult.setText("niveau elevé");
            else
            if (valeurMesuré<=10.5)
                tvResult.setText("niv minimal");
            else
                tvResult.setText("niveleve");

        }

    }

}